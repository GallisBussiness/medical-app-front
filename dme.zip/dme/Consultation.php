<?php

namespace App\Entity;

use App\Repository\ConsultationRepository;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ConsultationRepository::class)
 */
class Consultation
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=Dossier::class, inversedBy="consultations", cascade={"persist"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $dossier;

    /**
     * @ORM\Column(type="datetime")
     */
    private $dateDeConsultation;

    /**
     * @ORM\Column(type="float")
     */
    private $poids;

    /**
     * @ORM\Column(type="string", length=20, nullable=true)
     */
    private $tension;

    /**
     * @ORM\Column(type="string", length=20, nullable=true)
     */
    private $temperature;

    /**
     * @ORM\Column(type="string", length=120, nullable=true)
     */
    private $poule;

    /**
     * @ORM\Column(type="string", length=120, nullable=true)
     */
    private $glycemie;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $corpsCetoniques;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $autres;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $examen;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $diagnostique;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $traitement;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $bilan;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $prochainRDV;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $reference;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $plaintesDuJour;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $type;

    /**
     * @ORM\Column(type="string", length=20, nullable=false)
     */
    private $numero;

    /**
     * @ORM\OneToMany(targetEntity=Prescription::class, mappedBy="consultation")
     */
    private $prescriptions;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="consultations")
     */
    private $user;


    public function __construct()
    {
        $this->dateDeConsultation = new DateTime();
        $this->ordonnances = new ArrayCollection();
        $this->prescriptions = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDossier(): ?Dossier
    {
        return $this->dossier;
    }

    public function setDossier(?Dossier $dossier): self
    {
        $this->dossier = $dossier;

        return $this;
    }

    public function getDateDeConsultation(): ?\DateTimeInterface
    {
        return $this->dateDeConsultation;
    }

    public function setDateDeConsultation(\DateTimeInterface $dateDeConsultation): self
    {
        $this->dateDeConsultation = $dateDeConsultation;

        return $this;
    }

    public function getPoids(): ?float
    {
        return $this->poids;
    }

    public function setPoids(float $poids): self
    {
        $this->poids = $poids;

        return $this;
    }

    public function getTension(): ?string
    {
        return $this->tension;
    }

    public function setTension(?string $tension): self
    {
        $this->tension = $tension;

        return $this;
    }

    public function getTemperature(): ?string
    {
        return $this->temperature;
    }

    public function setTemperature(?string $temperature): self
    {
        $this->temperature = $temperature;

        return $this;
    }

    public function getPoule(): ?string
    {
        return $this->poule;
    }

    public function setPoule(?string $poule): self
    {
        $this->poule = $poule;

        return $this;
    }

    public function getGlycemie(): ?string
    {
        return $this->glycemie;
    }

    public function setGlycemie(?string $glycemie): self
    {
        $this->glycemie = $glycemie;

        return $this;
    }

    public function getCorpsCetoniques(): ?string
    {
        return $this->corpsCetoniques;
    }

    public function setCorpsCetoniques(?string $corpsCetoniques): self
    {
        $this->corpsCetoniques = $corpsCetoniques;

        return $this;
    }

    public function getAutres(): ?string
    {
        return $this->autres;
    }

    public function setAutres(?string $autres): self
    {
        $this->autres = $autres;

        return $this;
    }

    public function getExamen(): ?string
    {
        return $this->examen;
    }

    public function setExamen(?string $examen): self
    {
        $this->examen = $examen;

        return $this;
    }

    public function getDiagnostique(): ?string
    {
        return $this->diagnostique;
    }

    public function setDiagnostique(?string $diagnostique): self
    {
        $this->diagnostique = $diagnostique;

        return $this;
    }

    public function getTraitement(): ?string
    {
        return $this->traitement;
    }

    public function setTraitement(?string $traitement): self
    {
        $this->traitement = $traitement;

        return $this;
    }

    public function getBilan(): ?string
    {
        return $this->bilan;
    }

    public function setBilan(?string $bilan): self
    {
        $this->bilan = $bilan;

        return $this;
    }

    public function getProchainRDV(): ?\DateTimeInterface
    {
        return $this->prochainRDV;
    }

    public function setProchainRDV(?\DateTimeInterface $prochainRDV): self
    {
        $this->prochainRDV = $prochainRDV;

        return $this;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(?string $reference): self
    {
        $this->reference = $reference;

        return $this;
    }

    public function getPlaintesDuJour(): ?string
    {
        return $this->plaintesDuJour;
    }

    public function setPlaintesDuJour(?string $plaintesDuJour): self
    {
        $this->plaintesDuJour = $plaintesDuJour;

        return $this;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(?string $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function getNumero(): ?string
    {
        return $this->numero;
    }

    public function setNumero(?string $numero): self
    {
        $this->numero = $numero;

        return $this;
    }

    /**
     * @return Collection|Ordonnance[]
     */
    public function getOrdonnances(): Collection
    {
        return $this->ordonnances;
    }

    public function __toString()
    {
        return $this->numero;
    }

    /**
     * @return Collection|Prescription[]
     */
    public function getPrescriptions(): Collection
    {
        return $this->prescriptions;
    }

    public function addPrescription(Prescription $prescription): self
    {
        if (!$this->prescriptions->contains($prescription)) {
            $this->prescriptions[] = $prescription;
            $prescription->setConsultation($this);
        }

        return $this;
    }

    public function removePrescription(Prescription $prescription): self
    {
        if ($this->prescriptions->removeElement($prescription)) {
            // set the owning side to null (unless already changed)
            if ($prescription->getConsultation() === $this) {
                $prescription->setConsultation(null);
            }
        }

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }
}
