<?php

namespace App\Entity;

use App\Repository\DossierRepository;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=DossierRepository::class)
 */
class Dossier
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity=Etudiant::class, inversedBy="dossier", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $etudiant;

    /**
     * @ORM\Column(type="string", length=20, nullable=true)
     */
    private $groupeSanguin;

    /**
     * @ORM\Column(type="float", nullable=true)
     */
    private $poids;

    /**
     * @ORM\Column(type="float", nullable=true)
     */
    private $taille;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $handicapParticulier;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $maladieChronique;

    /**
     * @ORM\Column(type="json")
     */
    private $allergies = [];

    /**
     * @ORM\Column(type="datetime")
     */
    private $createAt;

    /**
     * @ORM\Column(type="datetime")
     */
    private $updatedAt;

    /**
     * @ORM\OneToMany(targetEntity=Consultation::class, mappedBy="dossier")
     */
    private $consultations;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $antecedantsMedicaux;

    /**
     * @ORM\OneToMany(targetEntity=Bulletin::class, mappedBy="dossier")
     */
    private $bulletins;

    public function __construct()
    {
        $this->createAt = new DateTime();
        $this->updatedAt = new DateTime();
        $this->consultations = new ArrayCollection();
        $this->bulletins = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEtudiant(): ?Etudiant
    {
        return $this->etudiant;
    }

    public function setEtudiant(Etudiant $etudiant): self
    {
        $this->etudiant = $etudiant;

        return $this;
    }

    public function getGroupeSanguin(): ?string
    {
        return $this->groupeSanguin;
    }

    public function setGroupeSanguin(?string $groupeSanguin): self
    {
        $this->groupeSanguin = $groupeSanguin;

        return $this;
    }

    public function getPoids(): ?float
    {
        return $this->poids;
    }

    public function setPoids(?float $poids): self
    {
        $this->poids = $poids;

        return $this;
    }

    public function getTaille(): ?float
    {
        return $this->taille;
    }

    public function setTaille(?float $taille): self
    {
        $this->taille = $taille;

        return $this;
    }

    public function getHandicapParticulier(): ?string
    {
        return $this->handicapParticulier;
    }

    public function setHandicapParticulier(?string $handicapParticulier): self
    {
        $this->handicapParticulier = $handicapParticulier;

        return $this;
    }

    public function getMaladieChronique(): ?string
    {
        return $this->maladieChronique;
    }

    public function setMaladieChronique(?string $maladieChronique): self
    {
        $this->maladieChronique = $maladieChronique;

        return $this;
    }

    /**
     * @see UserInterface
     */
    public function getAllergies(): array
    {
        $allergies = $this->allergies;

        return array_unique($allergies);
    }

    public function setAllergies(array $allergies): self
    {
        $this->allergies = $allergies;

        return $this;
    }

    public function getCreateAt(): ?\DateTime
    {
        return $this->createAt;
    }

    public function setCreateAt(\DateTimeImmutable $createAt): self
    {
        $this->createAt = $createAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTime
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeImmutable $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * @return Collection|Consultation[]
     */
    public function getConsultations(): Collection
    {
        return $this->consultations;
    }

    public function addConsultation(Consultation $consultation): self
    {
        if (!$this->consultations->contains($consultation)) {
            $this->consultations[] = $consultation;
            $consultation->setDossier($this);
        }

        return $this;
    }

    public function removeConsultation(Consultation $consultation): self
    {
        if ($this->consultations->removeElement($consultation)) {
            // set the owning side to null (unless already changed)
            if ($consultation->getDossier() === $this) {
                $consultation->setDossier(null);
            }
        }

        return $this;
    }


    public function __toString()
    {
        return $this->etudiant->__toString();
    }

    /**
     * @return Collection|Bulletin[]
     */
    public function getBulletins(): Collection
    {
        return $this->bulletins;
    }

    public function addBulletin(Bulletin $bulletin): self
    {
        if (!$this->bulletins->contains($bulletin)) {
            $this->bulletins[] = $bulletin;
            $bulletin->setDossier($this);
        }

        return $this;
    }

    public function removeBulletin(Bulletin $bulletin): self
    {
        if ($this->bulletins->removeElement($bulletin)) {
            // set the owning side to null (unless already changed)
            if ($bulletin->getDossier() === $this) {
                $bulletin->setDossier(null);
            }
        }

        return $this;
    }

    public function getAntecedantsMedicaux(): ?string
    {
        return $this->antecedantsMedicaux;
    }

    public function setAntecedantsMedicaux(?string $antecedantsMedicaux): self
    {
        $this->antecedantsMedicaux = $antecedantsMedicaux;

        return $this;
    }
}
